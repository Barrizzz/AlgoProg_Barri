class Barri:
    def __init__(self):
        self.stress = 1000000000
        self.health = 10    
        self.laziness = 'uwaw'
    
    def addHealth(self, addHeart): #input is the amount of heart
        self.health += addHeart
        if self.health >= 10:
            self.printHeart(10)
        else:
            self.printHeart(self.health)

    def removeHealth(self, removeHeart): #input is how many heart want to be removed
        self.health -= removeHeart
        if self.health <= 0:
            print("BARRI DIED! WHAT DID YOU DO!!!")
        else:
            self.printHeart(self.health)

    def addStress(self, stress): #input is the amount of stress
        self.stress += stress
        print(f'Your stress level is:\n{str(self.stress)}%')

    def giveFood(self): #interactive input for giving food, this can effect the health
        print('1. Milk of Prabowo\n2. Juice of Jokowi\n3. Baby oil\n4. Siomay')
        foodName = int(input("What do you want to give barri? (Please input the number): "))
        match foodName:
            case 1:
                self.addHealth(10)
            case 2:
                self.removeHealth(10)
            case 3:
                self.removeHealth(3)
            case 4:
                self.addHealth(7)

    def giveAssignment(self): #interactive input for giving assignments, this can effect the health and stress level
        print('1. HCI assignment\n2. AlgoProg assignment\n3. Scicomp assignment\n4. Dicrete Maths assignment')
        asgName = int(input("What do you want to give barri? (Please input the number): "))
        match asgName:
            case 1:
                self.removeHealth(10)
                self.addStress(99999999999999999)
            case 2:
                self.removeHealth(10)
                self.addStress(69)
            case 3:
                self.addHealth(100)
                self.addStress(-self.stress)
            case 4:
                self.addHealth(100)
                self.addStress(-self.stress)
    
    def laziness(self):
        print('Barri is to lazy to make this method')

    def printHeart(self, heart): #input is the amount of heart that just been added or removed
        print('Your Health is:')
        for i in range(heart):
            print('❤️', end='  ')
        print('')

test = Barri()
#test.addHealth(<heart amount>)
#test.removeHealth(<heart amount>)
#test.giveFood()
#test.giveAssignment()
#test.laziness()

    
