from math import pi

class Circle:
    def __init__(self):
        self.radius = 10
        self.color = 'BLACK'

    def getColor(self):
        print(self.color)
    
    def getCircum(self):
        print(2 * pi * self.radius)

test = Circle()
test.getColor()
test.getCircum()
