class Player:
    def __init__(self):
        self.invlist = []
        self.inv = {'Milk of Prabowo':64}
        self.money = 0
        self.health = 100
    
    def addItem(self, item, qtt):
        if item in self.inv:
            self.inv[item] += qtt
            self.invlist.append(self.inv[item])
        else:
            self.invlist.append({item: qtt})
        return self.invlist

    def removeItem(self, item, qtt):
        if item in self.inv:
            if self.inv[item] == qtt:
                del self.inv[item]
            else:
                new = self.inv[item] - qtt
                self.invlist.append({item: new})
        else:   
            print('That item is not in the Inventory')
        return self.invlist
            
    def addMoney(self, money):
        self.money += money
        return self.money

    def removeMoney(self, money):
        self.money -= money
        return self.money

    def removeHealth(self, damage):
        self.health = 100
        self.health -= damage
        if self.health <= 0:
            print("You died LOL")
        else:
            print("Your health is", self.health)

test = Player()
#print(test.addItem('Juice of Jokowi', 10))
#print(test.removeItem('Milk of Prabowo', 12))
#print(test.addMoney(2917396193))
#print(test.removeMoney(222))
test.removeHealth(100)
